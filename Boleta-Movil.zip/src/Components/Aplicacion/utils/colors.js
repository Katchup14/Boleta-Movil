
export default{
    PRIMARY_COLOR:'#0098D3',
    PRIMARY_COLOR_OSCURO:'#006691',
}